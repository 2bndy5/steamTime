//#include <atlbase.h> ATL for accessing registry in windows
#include <iostream>
#include <string>
#include <winerror.h>
#include "getLibInfo.h"
using namespace std;

int main()
{
	/*
	//HKEY_CURRENT_USER\SOFTWARE\Valve\Steam
	CRegKey SteamRegKey;
	if (SteamRegKey.Open(HKEY_CURRENT_USER, L"SOFTWARE\\Valve\\Steam", KEY_QUERY_VALUE) == 0L) {
		ULONG charSize = 255;
		LPTSTR value = L"";
		if (SteamRegKey.QueryStringValue(L"SteamPath", value, &charSize) == 0L) {
			cout << value << endl;
		}
		else
			cout << "error retrieving key" << endl;
	}
	cout << "error opening key" << endl;
	*/
	extractAllApps(getSteamID());

	return 0;
}