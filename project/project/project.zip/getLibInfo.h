#pragma comment(lib, "winhttp.lib")//works only visual studio
#include "windows.h"
#include "Winhttp.h"
#include <string>
#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;

BOOL ReadWebPage(string &source, bool secure, const wchar_t *url, const wchar_t *verb);
string getSteamID();
string getAccountNumber(string &uName);//user profile must have a custom URL set to user's steam ID for this to work correctly

// 2nd attempt gets library info from profile web page **includes software appIDs**
void extractAllApps(string &);

// 1st attempt to implement steam web API, but doesn't return software appIDs
void extractAppIds(bool, string &);